# QLDatVeXemPhim

Bản xuất MongoDB ngày 05/11/2026. Gồm 20 collection, 17.748 document, validator và index. Danh mục có 30 phim thật với đường dẫn ảnh dọc và ngang từ NguonC.

Giải nén, mở terminal ở thư mục chứa database/ và scripts/, rồi chạy:

    mongosh --quiet --file scripts/import_data.js

Script cần MongoDB đang chạy và database đích trống. Để nhập vào một database riêng trong PowerShell, đặt $env:TARGET_DB='QLDatVeXemPhim_restore' trước khi chạy.
